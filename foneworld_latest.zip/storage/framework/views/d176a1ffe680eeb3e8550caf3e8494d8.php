

 <?php $__env->startSection('content'); ?>

<div class="container mt-5">
<?php if(session()->has('message')): ?>
<div style="width: 400px;" class="alert alert-primary alert-dismissible bg-primary text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong><?php echo e(session('message')); ?> </strong> 
</div>
<?php endif; ?>
<h4>View Category Mobile List</h4>
<table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100 ">
    <thead>
        <tr>
            <th>id</th>
            <th>Name</th>
            <!-- <th>Description</th> -->
            <th>Edit</th>
            <th>Delete</th>
            
        </tr>
    </thead>


    <tbody>
        <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($device_data->id); ?></td>
            <td><?php echo e($device_data->name); ?></td>
            <!-- <td><?php echo e($device_data->mobile_description); ?></td> -->
            <td><a  href="<?php echo e(URL::to('super_admin/edit/mobile')); ?>/<?php echo e($device_data->id); ?>" class="btn btn-info">Edit</a></td>
        <td>
            <a href="<?php echo e(URL::to('super_admin/delete/mobile')); ?>/<?php echo e($device_data->id); ?>" class="btn btn-info">Delete</a>
        </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/admindashboard/layout/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\foneworld\resources\views/template/admindashboard/pages/mobile/view_mobile.blade.php ENDPATH**/ ?>