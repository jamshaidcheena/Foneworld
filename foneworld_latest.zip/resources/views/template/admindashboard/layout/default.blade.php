 @include('template/admindashboard/includes/header')


	 @yield('content')
		
 @include('template/admindashboard/includes/footer')