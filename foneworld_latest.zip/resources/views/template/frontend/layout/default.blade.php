 @include('template/frontend/includes/header')


	 @yield('content')
		
 @include('template/frontend/includes/footer')