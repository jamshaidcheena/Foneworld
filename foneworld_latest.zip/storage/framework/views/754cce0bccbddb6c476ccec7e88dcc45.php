 <?php echo $__env->make('template/frontend/includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	 <?php echo $__env->yieldContent('content'); ?>
		
 <?php echo $__env->make('template/frontend/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\foneworld\resources\views/template/frontend/layout/default.blade.php ENDPATH**/ ?>