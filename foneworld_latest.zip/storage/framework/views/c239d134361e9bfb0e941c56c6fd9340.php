

 <?php $__env->startSection('content'); ?>

<div class="container mt-5">
<?php if(session()->has('message')): ?>
<div style="width: 400px;" class="alert alert-primary alert-dismissible bg-primary text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong><?php echo e(session('message')); ?> </strong> 
</div>
<?php endif; ?>
<h4>View Bookings List</h4>
<table id="datatable-buttons" class="table table-striped dt-responsive nowrap w-100 ">
    <thead>
        <tr>
            <th>id</th>
            <th>Invoice No</th>
            <th>User Name</th>
            <th>Email</th>
            <th>Phone No</th>
            <th>Booking Date</th>
            <th>View Details</th>
            <th>Delete</th>
            
        </tr>
    </thead>


    <tbody>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookings_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($bookings_data->id); ?></td>
            <td><?php echo e($bookings_data->invoice_no ?? ''); ?></td>
            <td><?php echo e($bookings_data->c_first_name  ?? ''); ?> <?php echo e($bookings_data->c_last_name  ?? ''); ?></td>
            <td><?php echo e($bookings_data->c_email  ?? ''); ?></td>
            <td><?php echo e($bookings_data->c_phone_number  ?? ''); ?></td>
            <td><?php echo e($bookings_data->created_at  ?? ''); ?></td>
            <td><a href="<?php echo e(URL::to('super_admin/view/booking/detail')); ?>/<?php echo e($bookings_data->invoice_no); ?>" class="btn btn-info">View Detail</a></td>
        <td>
            <a href="<?php echo e(URL::to('super_admin/delete/booking')); ?>/<?php echo e($bookings_data->id); ?>" class="btn btn-info">Delete</a>
        </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/admindashboard/layout/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\foneworld\resources\views/template/admindashboard/pages/booking/view_bookings.blade.php ENDPATH**/ ?>