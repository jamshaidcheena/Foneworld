

 <?php $__env->startSection('content'); ?>





        

   <div>
    <div class="tab-content__pane" id="password">
                        <div class="">
                            <!-- BEGIN: Horizontal Bar Chart -->
                            <div class="">
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <h2 class="font-medium text-base mr-auto">
                                            Change Password
                                        </h2>
                                    </div>
                                    <?php if(session()->has('message')): ?>
<div style="width:400px;" class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
    <strong><?php echo e(session('message')); ?> </strong>
</div>
<?php endif; ?>
                                    <div class="card-body">
                                     <form class="ps-3 pe-3" action="<?php echo e(URL::to('super_admin/change-password')); ?>"  method="post">
                 <?php echo csrf_field(); ?>
       


                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="emailaddress" class="form-label">Current Password</label>
                        <input class="form-control"  type="password" id="current_password" name="current_password" value=""> 
                            </div>
                            
                            <div class="col-md-4">
                                <label for="emailaddress" class="form-label">New Password</label>
                        <input class="form-control"  type="password" id="new_password" name="new_password" value=""> 
                            </div>
                            <div class="col-md-4">
                                <label for="emailaddress" class="form-label">Confirm New Password</label>
                        <input class="form-control"  type="password" id="cnew_password" name="cnew_password" value=""> 
                            </div>
                        </div>
                       
                    </div>
                    
                   
                    
                    
                     
                    
                    
                    

                   

            
                    

                    <div class="mb-3">
                        <button name="submit" class="btn btn-primary" type="submit">submit</button>
                    </div>

                </form>

                                   </div>
                                </div>
                            </div>
                            <!-- END: Horizontal Bar Chart -->
                        </div>

                    </div>



   
       
    </div>
    <!-- END: Content -->




 <?php $__env->stopSection(); ?>
<?php echo $__env->make('template/admindashboard/layout/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\foneworld\resources\views/template/admindashboard/pages/setting/settings.blade.php ENDPATH**/ ?>